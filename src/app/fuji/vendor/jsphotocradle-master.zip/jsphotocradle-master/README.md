My old weird photo gallery, showing images from Flickr. Check the [demo](http://ytiurin.github.io/jsphotocradle/).
